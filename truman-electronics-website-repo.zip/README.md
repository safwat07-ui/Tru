# Truman Electronics — Website

Corporate marketing site for **Truman Electronics**, an Egyptian satellite and
home-electronics manufacturer founded in 1987.

The site is a single, self-contained `index.html` — no build step, no
dependencies, and **no external network requests** (fonts, scripts and the SVG
signal motif are all inline). Open it and it runs.

## Contents

| File | Purpose |
|------|---------|
| `index.html` | The entire website (structure, styles, and scripts inline) |
| `favicon.svg` | Brand mark — the satellite signal-lock glyph |
| `server.js` | Zero-dependency Node static server (for Railway / any Node host) |
| `package.json` | Start script + Node engine (lets Railway auto-detect the app) |
| `railway.json` | Railway build/deploy config |
| `.nojekyll` | Tells GitHub Pages to serve files as-is |
| `LICENSE` | Copyright notice |

## Run locally

Just open the file:

```bash
open index.html        # macOS
xdg-open index.html    # Linux
start index.html       # Windows
```

Or serve it (recommended, so relative paths behave like production):

```bash
python3 -m http.server 8000
# then visit http://localhost:8000
```

## Deploy

### GitHub Pages
1. Push this repo to GitHub.
2. **Settings → Pages → Source:** deploy from `main`, folder `/ (root)`.
3. The site goes live at `https://<user>.github.io/<repo>/`.

To use a custom domain (e.g. `www.truman-electronics.com`), add a file named
`CNAME` at the repo root containing just the domain, then point your DNS at
GitHub Pages.

### Railway
The repo ships ready for Railway — `server.js` serves the static files and binds
to Railway's injected `$PORT`; `package.json` and `railway.json` make the build
deterministic (Nixpacks, no dependencies to install).

**From the dashboard (easiest):**
1. Push this repo to GitHub.
2. On [railway.app](https://railway.app): **New Project → Deploy from GitHub repo**, and pick this repo.
3. Railway detects Node, runs `npm start` (`node server.js`), and deploys.
4. Open the service → **Settings → Networking → Generate Domain** to get a public URL. Add your own domain there if you have one.

**From the CLI:**
```bash
npm i -g @railway/cli
railway login
railway init          # create/link a project
railway up            # build & deploy this directory
railway domain        # generate a public URL
```

No environment variables are required — the server reads `PORT` automatically.

### Any static host
The site is plain static files — drag the folder into Netlify, Vercel,
Cloudflare Pages, or any web server. No configuration needed.

## Editing

Everything lives in `index.html`:

- **Colors & type** — the `:root` block near the top (`--ink`, `--amber`,
  `--paper`, plus the `--sans` / `--mono` / `--disp` font stacks).
- **Products** — the `#products` category grid and the "Featured lineup"
  cards. Model codes (e.g. `TM-G200`) are set in the monospace style.
- **Satellite tiers** — the `#satellite` section (Residential / Hospitality /
  Enterprise).
- **Contact details** — the `#contact` section (email, phone, locations).

### Fonts
To match the original design exactly (Archivo display + IBM Plex body/mono),
add the web-font files to a `fonts/` folder and declare them with `@font-face`,
then swap the `--disp`, `--sans`, and `--mono` values. As shipped, the site uses
system fonts so it renders identically offline and on every device.

## Notes
- Responsive down to mobile, with a collapsing menu.
- Respects `prefers-reduced-motion`.
- Keyboard focus styles included.

---
© 2026 Truman Electronics. All rights reserved.
