// Zero-dependency static server + contact API for Truman Electronics.
// Binds to Railway's injected $PORT on 0.0.0.0. No npm dependencies.
const http = require('http');
const fs = require('fs');
const path = require('path');

const PORT = process.env.PORT || 3000;
const ROOT = __dirname;

const MIME = {
  '.html':'text/html; charset=utf-8', '.css':'text/css; charset=utf-8',
  '.js':'text/javascript; charset=utf-8', '.svg':'image/svg+xml',
  '.png':'image/png', '.jpg':'image/jpeg', '.jpeg':'image/jpeg',
  '.gif':'image/gif', '.webp':'image/webp', '.ico':'image/x-icon',
  '.json':'application/json; charset=utf-8', '.xml':'application/xml; charset=utf-8', '.pdf':'application/pdf',
  '.txt':'text/plain; charset=utf-8', '.woff2':'font/woff2', '.woff':'font/woff'
};

function send(res, code, type, body){ res.writeHead(code, {'Content-Type':type}); res.end(body); }

// ---- Contact form handler ----
async function handleContact(req, res){
  let raw='';
  req.on('data', c => { raw += c; if (raw.length > 1e5) req.destroy(); });
  req.on('end', async () => {
    let d = {};
    try {
      d = (req.headers['content-type']||'').includes('application/json')
        ? JSON.parse(raw || '{}')
        : Object.fromEntries(new URLSearchParams(raw));
    } catch(e){ return send(res,400,'application/json','{"ok":false,"error":"bad body"}'); }

    const name=(d.name||'').trim(), email=(d.email||'').trim(),
          message=(d.message||'').trim(), topic=(d.topic||'General').trim();
    if(!name || !message || !/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email))
      return send(res,422,'application/json','{"ok":false,"error":"invalid fields"}');

    const payload = { name, email, topic, message, at:new Date().toISOString() };

    try{
      if(process.env.CONTACT_WEBHOOK_URL){
        // Works with Slack, Discord, Zapier, Make, n8n, etc.
        await fetch(process.env.CONTACT_WEBHOOK_URL,{
          method:'POST', headers:{'Content-Type':'application/json'},
          body: JSON.stringify({ text:`New Truman enquiry — ${topic}\nFrom: ${name} <${email}>\n\n${message}`, ...payload })
        });
      } else if(process.env.RESEND_API_KEY && process.env.CONTACT_TO && process.env.CONTACT_FROM){
        await fetch('https://api.resend.com/emails',{
          method:'POST',
          headers:{'Authorization':'Bearer '+process.env.RESEND_API_KEY,'Content-Type':'application/json'},
          body: JSON.stringify({
            from: process.env.CONTACT_FROM, to: process.env.CONTACT_TO, reply_to: email,
            subject: `Website enquiry (${topic}) — ${name}`,
            text: `From: ${name} <${email}>\nTopic: ${topic}\n\n${message}`
          })
        });
      } else {
        // No delivery configured yet — log so nothing is lost while testing.
        console.log('[contact] (no delivery configured)', JSON.stringify(payload));
      }
      return send(res,200,'application/json','{"ok":true}');
    }catch(err){
      console.error('[contact] delivery failed:', err && err.message);
      return send(res,502,'application/json','{"ok":false,"error":"delivery failed"}');
    }
  });
}

const server = http.createServer((req, res) => {
  try{
    if(req.method==='POST' && req.url.split('?')[0]==='/api/contact') return handleContact(req,res);
    if(req.method!=='GET' && req.method!=='HEAD') return send(res,405,'text/plain','Method Not Allowed');

    let urlPath = decodeURIComponent(req.url.split('?')[0]);
    if(urlPath==='/') urlPath='/index.html';
    const safePath = path.normalize(path.join(ROOT, urlPath));
    if(!safePath.startsWith(ROOT)) return send(res,403,'text/plain','Forbidden');

    fs.readFile(safePath,(err,data)=>{
      if(err){
        // serve custom 404 page
        return fs.readFile(path.join(ROOT,'404.html'),(e2,nf)=>{
          if(e2) return send(res,404,'text/plain','Not found');
          send(res,404,'text/html; charset=utf-8',nf);
        });
      }
      const ext=path.extname(safePath).toLowerCase();
      const type=MIME[ext]||'application/octet-stream';
      const headers={'Content-Type':type};
      if(ext!=='.html') headers['Cache-Control']='public, max-age=3600';
      res.writeHead(200,headers);
      res.end(req.method==='HEAD' ? undefined : data);
    });
  }catch(e){ send(res,500,'text/plain','Server error'); }
});

server.listen(PORT,'0.0.0.0',()=>console.log('Truman Electronics site running on port '+PORT));
